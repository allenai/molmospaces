/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef TNT_FILAMENT_BACKEND_PRIVATE_DRIVERAPI_H
#define TNT_FILAMENT_BACKEND_PRIVATE_DRIVERAPI_H

#include <private/backend/CommandStream.h>

#include <backend/DriverApiForward.h>

#include <stddef.h>

namespace filament::backend {

inline void* allocateFromCommandStream(DriverApi& driver, size_t size, size_t alignment) noexcept {
    return driver.allocate(size, alignment);
}

} // namespace filament::backend

#endif // TNT_FILAMENT_BACKEND_PRIVATE_DRIVERAPI_H
