// Copyright 2026 DeepMind Technologies Limited
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef MUJOCO_SRC_EXPERIMENTAL_STUDIO_HAL_EGL_UTILS_H_
#define MUJOCO_SRC_EXPERIMENTAL_STUDIO_HAL_EGL_UTILS_H_

#include <memory>

namespace mujoco::studio {

// Creates an opaque handle to an initialized EGL context and display.
// Resetting this handle will destroy the context and release the display.
std::shared_ptr<void> CreateEglContext();

}  // namespace mujoco::studio

#endif  // MUJOCO_SRC_EXPERIMENTAL_STUDIO_HAL_EGL_UTILS_H_
