/*
* Copyright (C) 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef TNT_FILAMENT_BACKEND_PLATFORMS_WEBGPUPLATFORMANDROID_H
#define TNT_FILAMENT_BACKEND_PLATFORMS_WEBGPUPLATFORMANDROID_H

#include "AndroidNdk.h"

#include <backend/platforms/WebGPUPlatform.h>

namespace filament::backend {

class WebGPUPlatformAndroid : public WebGPUPlatform, public AndroidNdk {
public:
    WebGPUPlatformAndroid() noexcept;
    ~WebGPUPlatformAndroid() noexcept override;

    wgpu::Extent2D getSurfaceExtent(void* nativeWindow) const override;
    wgpu::Surface createSurface(void* nativeWindow, uint64_t /*flags*/) override;

    utils::tribool isFrameRateChangeSupported(void* nativeWindow) const noexcept override;
    int setFrameRate(SwapChain const* swapchain, float frameRate,
            FrameRateCompatibility compatibility,
            ChangeFrameRateStrategy strategy) noexcept override;


protected:
    std::vector<wgpu::RequestAdapterOptions> getAdapterOptions() override;
};

} // namespace filament::backend

#endif // TNT_FILAMENT_BACKEND_PLATFORMS_WEBGPUPLATFORMANDROID_H
